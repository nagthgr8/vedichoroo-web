VedicHoroo Software - Installation Guide  
=======================================  

Version: 1.0.0  

Thank you for subscribing to VedicHoroo! This software package includes the **Report Generation Tool** and **Prashna Software** for your astrology needs.  

Follow the steps below to get started:  

Step 1: Install .NET 8.0 Desktop Runtime  
---------------------------------------  
Before you can use the VedicHoroo software, you need to install the .NET 8.0 Desktop Runtime. This is required to run the Windows Forms applications.  

1. Download the .NET 8.0 Desktop Runtime from the following link:  
   https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/runtime-desktop-8.0.11-windows-x64-installer  

2. Once downloaded, run the installer and follow the on-screen instructions to complete the installation.  

Step 2: Extract the Zip File  
----------------------------  
After downloading the zip file, extract it to a folder of your choice.  

Step 3: Grant Write Permissions to the Folder  
---------------------------------------------  
1. Right-click on the extracted folder and select "Properties".  
2. Go to the "Security" tab.  
3. Click on "Edit" and give full write permissions to the folder for your user account.  

Step 4: Run the Software  
------------------------  
1. For Report Generation Tool:  
   - Navigate to the extracted folder and run `VedicHorooReports.exe` to generate astrology reports.  

2. For Prashna Software:  
   - Navigate to the extracted folder and run `Prashna.exe` to use the Prashna tool for astrology analysis.  

---------------------------------------------------------------  

Feel free to reach out if you encounter any issues. Enjoy using VedicHoroo!  
